# NorCal Equity Partners — Seller Lead Portal (Minimal Full Repo)

This repository contains a minimal, ready-to-run example of a seller lead portal for
`norcalequitypartners.com`. It includes:

- A Node/Express backend (`/backend`) that accepts lead submissions, computes an eligibility score,
  stores leads in MongoDB (Mongoose), and sends an email notification.
- A React frontend (`/frontend`) with a simple Sell form that posts leads to the backend.
- Example environment variables and instructions.

**Important:** This is a minimal starter scaffold intended for local testing and deployment. Before production:
- Replace placeholder secrets in `.env` with real credentials.
- Add HTTPS, rate-limiting, input sanitization, and CAPTCHA (reCAPTCHA).
- Harden admin authentication and add proper file storage (S3) for images.

## What's included
- `/backend` — Express server, Mongoose model, eligibility logic, mailer (nodemailer).
- `/frontend` — React app (minimal) with Sell form.
- `.env.example` — environment variables you must set.
- `docker-compose` is NOT included but you can dockerize using provided Dockerfile as a starting point.

## Quick local run (dev)

### Prerequisites
- Node.js 18+ and npm
- MongoDB instance (local or Atlas)

### Backend
```bash
cd backend
cp .env.example .env
# edit .env with real values
npm install
npm run dev
# server runs on http://localhost:4000
```

### Frontend
```bash
cd frontend
npm install
npm start
# frontend runs on http://localhost:3000 and proxies API requests to the backend in dev
```

## Production deployment notes
- Host frontend on Vercel/Netlify and backend on Render/Heroku/DigitalOcean.
- Use MongoDB Atlas and AWS S3 (for images).
- Point DNS for `norcalequitypartners.com` and enable HTTPS.
- Configure SMTP provider (SendGrid/Postmark) for reliable email delivery.

## Contact
This starter was generated automatically. Tweak the eligibility logic in `backend/eligibility.js` and expand the admin UI as needed.
